# runs a modded command the mcfunction checker (mecha, vanilla command tree) cannot parse: function dungeon_heroes:mod_command {cmd: "<command>"}
$$(cmd)
