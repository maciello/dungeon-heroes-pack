# /trigger dh_reset: every skill tree back to 0 spent points (passive tree + Skill Tree RPGs class and weapon trees; the Orb of Oblivion resets only those two)
function dungeon_heroes:mod_command {cmd: "puffish_skills skills reset @s dungeon_heroes:passives"}
function dungeon_heroes:mod_command {cmd: "puffish_skills skills reset @s skill_tree_rpgs:class_skills"}
function dungeon_heroes:mod_command {cmd: "puffish_skills skills reset @s skill_tree_rpgs:weapon_skills"}
tellraw @s {"text":"All skill trees reset: your points are back.","color":"green"}
scoreboard players reset @s dh_reset
