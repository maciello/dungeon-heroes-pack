schedule function dungeon_heroes:tick 5t replace
execute as @a at @s run function dungeon_heroes:player
