# Glass Cannon (tag dh_glass): 50% MORE spell power (×1.5 multiplied, every spell school incl. healing)
# 2.6.1 ×1.6 holders (old tag dh_glass_mod): strip the old modifier once; the lines below add ×1.5
execute if entity @s[tag=dh_glass_mod] run function dungeon_heroes:mech/glass_off
execute if entity @s[tag=dh_glass,tag=!dh_glass_m50] run attribute @s spell_power:arcane modifier add dungeon_heroes:glass 0.5 add_multiplied_total
execute if entity @s[tag=dh_glass,tag=!dh_glass_m50] run attribute @s spell_power:fire modifier add dungeon_heroes:glass 0.5 add_multiplied_total
execute if entity @s[tag=dh_glass,tag=!dh_glass_m50] run attribute @s spell_power:frost modifier add dungeon_heroes:glass 0.5 add_multiplied_total
execute if entity @s[tag=dh_glass,tag=!dh_glass_m50] run attribute @s spell_power:healing modifier add dungeon_heroes:glass 0.5 add_multiplied_total
execute if entity @s[tag=dh_glass,tag=!dh_glass_m50] run attribute @s spell_power:air modifier add dungeon_heroes:glass 0.5 add_multiplied_total
execute if entity @s[tag=dh_glass,tag=!dh_glass_m50] run attribute @s spell_power:earth modifier add dungeon_heroes:glass 0.5 add_multiplied_total
execute if entity @s[tag=dh_glass,tag=!dh_glass_m50] run attribute @s spell_power:water modifier add dungeon_heroes:glass 0.5 add_multiplied_total
execute if entity @s[tag=dh_glass,tag=!dh_glass_m50] run attribute @s spell_power:lightning modifier add dungeon_heroes:glass 0.5 add_multiplied_total
execute if entity @s[tag=dh_glass,tag=!dh_glass_m50] run attribute @s spell_power:soul modifier add dungeon_heroes:glass 0.5 add_multiplied_total
execute if entity @s[tag=dh_glass,tag=!dh_glass_m50] run tag @s add dh_glass_m50
execute if entity @s[tag=!dh_glass,tag=dh_glass_m50] run function dungeon_heroes:mech/glass_off
