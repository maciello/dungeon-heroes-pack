# Glass Cannon (tag dh_glass): 60% MORE spell power (×1.6 multiplied, every spell school incl. healing)
execute if entity @s[tag=dh_glass,tag=!dh_glass_mod] run attribute @s spell_power:arcane modifier add dungeon_heroes:glass 0.6 add_multiplied_total
execute if entity @s[tag=dh_glass,tag=!dh_glass_mod] run attribute @s spell_power:fire modifier add dungeon_heroes:glass 0.6 add_multiplied_total
execute if entity @s[tag=dh_glass,tag=!dh_glass_mod] run attribute @s spell_power:frost modifier add dungeon_heroes:glass 0.6 add_multiplied_total
execute if entity @s[tag=dh_glass,tag=!dh_glass_mod] run attribute @s spell_power:healing modifier add dungeon_heroes:glass 0.6 add_multiplied_total
execute if entity @s[tag=dh_glass,tag=!dh_glass_mod] run attribute @s spell_power:air modifier add dungeon_heroes:glass 0.6 add_multiplied_total
execute if entity @s[tag=dh_glass,tag=!dh_glass_mod] run attribute @s spell_power:earth modifier add dungeon_heroes:glass 0.6 add_multiplied_total
execute if entity @s[tag=dh_glass,tag=!dh_glass_mod] run attribute @s spell_power:water modifier add dungeon_heroes:glass 0.6 add_multiplied_total
execute if entity @s[tag=dh_glass,tag=!dh_glass_mod] run attribute @s spell_power:lightning modifier add dungeon_heroes:glass 0.6 add_multiplied_total
execute if entity @s[tag=dh_glass,tag=!dh_glass_mod] run attribute @s spell_power:soul modifier add dungeon_heroes:glass 0.6 add_multiplied_total
execute if entity @s[tag=dh_glass,tag=!dh_glass_mod] run tag @s add dh_glass_mod
execute if entity @s[tag=!dh_glass,tag=dh_glass_mod] run function dungeon_heroes:mech/glass_off
