# Warded Focus (tag dh_focus): a shield, totem or magic orb in the off-hand (item tag dungeon_heroes:spell_focus) → +20 % spell power; wand + off-hand beats a two-handed staff
execute if entity @s[tag=dh_focus] if predicate dungeon_heroes:spell_focus run function dungeon_heroes:mech/focus_on
execute unless entity @s[tag=dh_focus] run function dungeon_heroes:mech/focus_off
execute unless predicate dungeon_heroes:spell_focus run function dungeon_heroes:mech/focus_off
