attribute @s ranged_weapon:damage modifier add dungeon_heroes:night_hunter 0.2 add_multiplied_base
attribute @s critical_strike:chance modifier add dungeon_heroes:night_hunter 10 add_value
