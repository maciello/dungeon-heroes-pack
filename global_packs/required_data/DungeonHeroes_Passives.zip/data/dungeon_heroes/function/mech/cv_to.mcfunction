# conversion step 3 (macro: id, n, dst, pct): dst gains pct % of the bonus (modifier dungeon_heroes:<id>_<n>)
scoreboard players operation @s dh_b = @s dh_v
$scoreboard players set #pct dh_const $(pct)
scoreboard players operation @s dh_b *= #pct dh_const
execute store result storage dungeon_heroes:cv amt double 0.0001 run scoreboard players get @s dh_b
$data modify storage dungeon_heroes:cv id set value "$(id)_$(n)"
$data modify storage dungeon_heroes:cv attr set value "$(dst)"
function dungeon_heroes:mech/cv_add with storage dungeon_heroes:cv
