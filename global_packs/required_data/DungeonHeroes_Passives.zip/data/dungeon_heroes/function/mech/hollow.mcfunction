# Hollow Vessel (tag dh_hollow): max health ×0 (clamps to the attribute minimum = 2 HP, config/attributefix/minecraft/generic.max_health.json), +16 generic.max_absorption (8 hearts) and 60% MORE max_absorption. Armor +2 and toughness +1 are node rewards; extra max health converts in mech/cv_hollow.
# dh_hollow_mod = the old applied-tag (6 hearts, 50% MORE): clean it up once, then the v2 modifiers go on
execute if entity @s[tag=dh_hollow_mod] run function dungeon_heroes:mech/hollow_off
execute if entity @s[tag=dh_hollow,tag=!dh_hollow_v2] run attribute @s minecraft:generic.max_health modifier add dungeon_heroes:hollow -1 add_multiplied_total
execute if entity @s[tag=dh_hollow,tag=!dh_hollow_v2] run attribute @s minecraft:generic.max_absorption modifier add dungeon_heroes:hollow 16 add_value
execute if entity @s[tag=dh_hollow,tag=!dh_hollow_v2] run attribute @s minecraft:generic.max_absorption modifier add dungeon_heroes:hollow_more 0.6 add_multiplied_total
execute if entity @s[tag=dh_hollow,tag=!dh_hollow_v2] run tag @s add dh_hollow_v2
execute if entity @s[tag=!dh_hollow,tag=dh_hollow_v2] run function dungeon_heroes:mech/hollow_off
