# Hollow Vessel (tag dh_hollow): max health ×0 (clamps to 1 HP), +12 generic.max_absorption (6 hearts) and 50% MORE max_absorption
execute if entity @s[tag=dh_hollow,tag=!dh_hollow_mod] run attribute @s minecraft:generic.max_health modifier add dungeon_heroes:hollow_hp -1 add_multiplied_total
execute if entity @s[tag=dh_hollow,tag=!dh_hollow_mod] run attribute @s minecraft:generic.max_absorption modifier add dungeon_heroes:hollow 12 add_value
execute if entity @s[tag=dh_hollow,tag=!dh_hollow_mod] run attribute @s minecraft:generic.max_absorption modifier add dungeon_heroes:hollow_more 0.5 add_multiplied_total
execute if entity @s[tag=dh_hollow,tag=!dh_hollow_mod] run tag @s add dh_hollow_mod
execute if entity @s[tag=!dh_hollow,tag=dh_hollow_mod] run function dungeon_heroes:mech/hollow_off
