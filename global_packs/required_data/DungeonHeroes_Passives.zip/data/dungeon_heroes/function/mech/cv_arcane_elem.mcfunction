# Elemental Diffusion (tag=dh_cv_arcane_elem): converted by dh_addon Conversions (Java) — arcane % → each element % in full, flat at 0.6, MORE stays.
# Here only: remove the modifiers of the old datapack conversion once (it read the final value, so MORE compounded per hop).
execute if score @s dh_cv_arcane_elem matches 0.. run attribute @s spell_power:earth modifier remove dungeon_heroes:cv_arcane_elem_4
execute if score @s dh_cv_arcane_elem matches 0.. run attribute @s spell_power:water modifier remove dungeon_heroes:cv_arcane_elem_5
execute if score @s dh_cv_arcane_elem matches 0.. run attribute @s spell_power:lightning modifier remove dungeon_heroes:cv_arcane_elem_6
execute if score @s dh_cv_arcane_elem matches 0.. run function dungeon_heroes:mech/cv_off {id:"cv_arcane_elem", src:"spell_power:arcane", d1:"spell_power:fire", d2:"spell_power:frost", d3:"spell_power:air"}
