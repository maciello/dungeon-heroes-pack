# Elemental Diffusion: your arcane spell power bonus is lost; fire, frost, air, earth, water and lightning spell power each gain 50 % of it (tag dh_cv_arcane_elem)
execute if entity @s[tag=dh_cv_arcane_elem] run function dungeon_heroes:mech/cv_read {id:"cv_arcane_elem", src:"spell_power:arcane"}
execute if entity @s[tag=dh_cv_arcane_elem] run function dungeon_heroes:mech/cv_drain {id:"cv_arcane_elem", src:"spell_power:arcane"}
execute if entity @s[tag=dh_cv_arcane_elem] if score @s dh_chg matches 1 run function dungeon_heroes:mech/cv_to {id:"cv_arcane_elem", n:1, dst:"spell_power:fire", pct:50}
execute if entity @s[tag=dh_cv_arcane_elem] if score @s dh_chg matches 1 run function dungeon_heroes:mech/cv_to {id:"cv_arcane_elem", n:2, dst:"spell_power:frost", pct:50}
execute if entity @s[tag=dh_cv_arcane_elem] if score @s dh_chg matches 1 run function dungeon_heroes:mech/cv_to {id:"cv_arcane_elem", n:3, dst:"spell_power:air", pct:50}
execute if entity @s[tag=dh_cv_arcane_elem] if score @s dh_chg matches 1 run function dungeon_heroes:mech/cv_to {id:"cv_arcane_elem", n:4, dst:"spell_power:earth", pct:50}
execute if entity @s[tag=dh_cv_arcane_elem] if score @s dh_chg matches 1 run function dungeon_heroes:mech/cv_to {id:"cv_arcane_elem", n:5, dst:"spell_power:water", pct:50}
execute if entity @s[tag=dh_cv_arcane_elem] if score @s dh_chg matches 1 run function dungeon_heroes:mech/cv_to {id:"cv_arcane_elem", n:6, dst:"spell_power:lightning", pct:50}
execute if entity @s[tag=!dh_cv_arcane_elem] if score @s dh_cv_arcane_elem matches 0.. run attribute @s spell_power:earth modifier remove dungeon_heroes:cv_arcane_elem_4
execute if entity @s[tag=!dh_cv_arcane_elem] if score @s dh_cv_arcane_elem matches 0.. run attribute @s spell_power:water modifier remove dungeon_heroes:cv_arcane_elem_5
execute if entity @s[tag=!dh_cv_arcane_elem] if score @s dh_cv_arcane_elem matches 0.. run attribute @s spell_power:lightning modifier remove dungeon_heroes:cv_arcane_elem_6
execute if entity @s[tag=!dh_cv_arcane_elem] if score @s dh_cv_arcane_elem matches 0.. run function dungeon_heroes:mech/cv_off {id:"cv_arcane_elem", src:"spell_power:arcane", d1:"spell_power:fire", d2:"spell_power:frost", d3:"spell_power:air"}
