attribute @s spell_power:arcane modifier add dungeon_heroes:shielded 0.2 add_multiplied_base
attribute @s spell_power:fire modifier add dungeon_heroes:shielded 0.2 add_multiplied_base
attribute @s spell_power:frost modifier add dungeon_heroes:shielded 0.2 add_multiplied_base
