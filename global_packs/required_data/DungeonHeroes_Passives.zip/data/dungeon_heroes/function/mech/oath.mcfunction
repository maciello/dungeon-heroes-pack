# Oaths are plain stat lines now; removes the old datapack Oath bonus from players who still carry an Oath tag
execute if entity @s[tag=dh_oath_fire] run function dungeon_heroes:mech/oath_off
tag @s remove dh_oath_fire
execute if entity @s[tag=dh_oath_frost] run function dungeon_heroes:mech/oath_off
tag @s remove dh_oath_frost
execute if entity @s[tag=dh_oath_air] run function dungeon_heroes:mech/oath_off
tag @s remove dh_oath_air
execute if entity @s[tag=dh_oath_water] run function dungeon_heroes:mech/oath_off
tag @s remove dh_oath_water
execute if entity @s[tag=dh_oath_earth] run function dungeon_heroes:mech/oath_off
tag @s remove dh_oath_earth
