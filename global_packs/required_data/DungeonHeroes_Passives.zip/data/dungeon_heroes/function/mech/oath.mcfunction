# Oaths (tags dh_oath_<element>): an elementalist commits to one element; exactly one Oath held → its bonus, two or more cancel out (Boss: 'MUTUALLY EXCLUSIVE earth fire frost air water')
scoreboard players set @s dh_v 0
execute if entity @s[tag=dh_oath_fire] run scoreboard players add @s dh_v 1
execute if entity @s[tag=dh_oath_frost] run scoreboard players add @s dh_v 1
execute if entity @s[tag=dh_oath_air] run scoreboard players add @s dh_v 1
execute if entity @s[tag=dh_oath_water] run scoreboard players add @s dh_v 1
execute if entity @s[tag=dh_oath_earth] run scoreboard players add @s dh_v 1
execute unless score @s dh_v matches 1 run function dungeon_heroes:mech/oath_off
execute if score @s dh_v matches 1 if entity @s[tag=dh_oath_fire] run function dungeon_heroes:mech/oath_fire
execute if score @s dh_v matches 1 if entity @s[tag=dh_oath_frost] run function dungeon_heroes:mech/oath_frost
execute if score @s dh_v matches 1 if entity @s[tag=dh_oath_air] run function dungeon_heroes:mech/oath_air
execute if score @s dh_v matches 1 if entity @s[tag=dh_oath_water] run function dungeon_heroes:mech/oath_water
execute if score @s dh_v matches 1 if entity @s[tag=dh_oath_earth] run function dungeon_heroes:mech/oath_earth
