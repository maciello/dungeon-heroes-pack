# (macro: id, attr, amt) one final-multiplier modifier, replaced
$attribute @s $(attr) modifier remove dungeon_heroes:$(id)
$attribute @s $(attr) modifier add dungeon_heroes:$(id) $(amt) add_multiplied_total
