function dungeon_heroes:mech/oath_off
attribute @s spell_power:fire modifier add dungeon_heroes:oath 0.3 add_multiplied_base
attribute @s spell_power:critical_damage modifier add dungeon_heroes:oath 25 add_value
