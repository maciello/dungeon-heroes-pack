function dungeon_heroes:mech/oath_off
attribute @s spell_power:fire modifier add dungeon_heroes:oath 0.3 add_multiplied_base
attribute @s more_rpg_classes:burning_chance modifier add dungeon_heroes:oath 15 add_value
