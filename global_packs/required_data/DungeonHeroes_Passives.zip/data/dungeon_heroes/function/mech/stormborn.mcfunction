# Stormborn: in water or rain → +25 % air and water spell power (tag dh_stormborn)
execute if entity @s[tag=dh_stormborn] if predicate dungeon_heroes:wet run function dungeon_heroes:mech/stormborn_on
execute unless entity @s[tag=dh_stormborn] run function dungeon_heroes:mech/stormborn_off
execute unless predicate dungeon_heroes:wet run function dungeon_heroes:mech/stormborn_off
