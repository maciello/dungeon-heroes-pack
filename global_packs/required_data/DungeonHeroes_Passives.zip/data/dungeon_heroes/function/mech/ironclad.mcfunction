# Ironclad Stance: while sneaking → +50 % armor, +50 % knockback resistance (tag dh_ironclad)
execute if entity @s[tag=dh_ironclad] if predicate dungeon_heroes:sneaking run function dungeon_heroes:mech/ironclad_on
execute unless entity @s[tag=dh_ironclad] run function dungeon_heroes:mech/ironclad_off
execute unless predicate dungeon_heroes:sneaking run function dungeon_heroes:mech/ironclad_off
