attribute @s spell_power:arcane modifier remove dungeon_heroes:focus
attribute @s spell_power:fire modifier remove dungeon_heroes:focus
attribute @s spell_power:frost modifier remove dungeon_heroes:focus
attribute @s spell_power:healing modifier remove dungeon_heroes:focus
attribute @s spell_power:air modifier remove dungeon_heroes:focus
attribute @s spell_power:earth modifier remove dungeon_heroes:focus
attribute @s spell_power:water modifier remove dungeon_heroes:focus
