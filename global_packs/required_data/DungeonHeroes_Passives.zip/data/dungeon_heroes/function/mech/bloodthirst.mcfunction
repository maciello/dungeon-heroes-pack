# Bloodthirst (tag dh_bloodthirst): every kill → Regeneration II 3 s
execute if entity @s[tag=dh_bloodthirst,scores={dh_kills=1..}] run effect give @s minecraft:regeneration 3 1 true
