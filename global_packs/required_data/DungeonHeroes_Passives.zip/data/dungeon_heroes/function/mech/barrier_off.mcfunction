attribute @s minecraft:generic.max_absorption modifier remove dungeon_heroes:barrier
scoreboard players reset @s dh_barrier_v
tag @s remove dh_barrier_mod
