effect clear @s minecraft:absorption
tag @s remove dh_barrier_on
