# Night Hunter: at night or in darkness (light ≤ 7) → +20 % ranged damage, +10 % crit chance (tag dh_night_hunter)
execute if entity @s[tag=dh_night_hunter] if predicate dungeon_heroes:night_or_dark run function dungeon_heroes:mech/night_hunter_on
execute unless entity @s[tag=dh_night_hunter] run function dungeon_heroes:mech/night_hunter_off
execute unless predicate dungeon_heroes:night_or_dark run function dungeon_heroes:mech/night_hunter_off
