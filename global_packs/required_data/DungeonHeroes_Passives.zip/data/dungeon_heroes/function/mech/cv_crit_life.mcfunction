# Blood over Edge: your crit chance bonus is lost; +1 max health per 2 % of it (tag dh_cv_crit_life)
execute if entity @s[tag=dh_cv_crit_life] run function dungeon_heroes:mech/cv_read {id:"cv_crit_life", src:"critical_strike:chance"}
execute if entity @s[tag=dh_cv_crit_life] run function dungeon_heroes:mech/cv_drain {id:"cv_crit_life", src:"critical_strike:chance"}
execute if entity @s[tag=dh_cv_crit_life] if score @s dh_chg matches 1 run function dungeon_heroes:mech/cv_to {id:"cv_crit_life", n:1, dst:"minecraft:generic.max_health", pct:50}
execute if entity @s[tag=!dh_cv_crit_life] if score @s dh_cv_crit_life matches 0.. run function dungeon_heroes:mech/cv_off {id:"cv_crit_life", src:"critical_strike:chance", d1:"minecraft:generic.max_health", d2:"minecraft:generic.max_health", d3:"minecraft:generic.max_health"}
