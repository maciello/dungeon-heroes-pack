# Berserker's Fury: below 50 % health → +30 % attack damage, +15 % attack speed (tag dh_fury)
execute if entity @s[tag=dh_fury] if entity @s[scores={dh_pct=..49}] run function dungeon_heroes:mech/fury_on
execute unless entity @s[tag=dh_fury] run function dungeon_heroes:mech/fury_off
execute unless entity @s[scores={dh_pct=..49}] run function dungeon_heroes:mech/fury_off
