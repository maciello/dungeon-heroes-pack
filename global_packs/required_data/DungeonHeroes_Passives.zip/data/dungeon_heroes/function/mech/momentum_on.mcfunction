attribute @s minecraft:generic.attack_damage modifier add dungeon_heroes:momentum 0.1 add_multiplied_base
attribute @s minecraft:generic.movement_speed modifier add dungeon_heroes:momentum 0.1 add_multiplied_base
