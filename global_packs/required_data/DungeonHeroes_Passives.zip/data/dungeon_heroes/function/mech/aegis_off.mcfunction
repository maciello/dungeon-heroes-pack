effect clear @s minecraft:absorption
tag @s remove dh_aegis_on
