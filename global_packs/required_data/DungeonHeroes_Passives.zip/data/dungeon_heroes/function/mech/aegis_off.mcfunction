attribute @s minecraft:generic.max_absorption modifier remove dungeon_heroes:aegis
tag @s remove dh_aegis_mod
