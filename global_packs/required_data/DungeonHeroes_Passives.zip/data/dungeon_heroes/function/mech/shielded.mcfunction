# Shielded Mind (tag dh_shielded): while you have absorption hearts → +20 % arcane, fire and frost spell power
execute if entity @s[tag=dh_shielded] if predicate dungeon_heroes:has_absorption run function dungeon_heroes:mech/shielded_on
execute unless entity @s[tag=dh_shielded] run function dungeon_heroes:mech/shielded_off
execute unless predicate dungeon_heroes:has_absorption run function dungeon_heroes:mech/shielded_off
