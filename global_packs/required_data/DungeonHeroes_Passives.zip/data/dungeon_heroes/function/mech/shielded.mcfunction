# Shielded Mind (tag dh_shielded): while you have absorption hearts → +20 % spell power of every school but healing
execute store result score @s dh_v run data get entity @s AbsorptionAmount 10
execute if entity @s[tag=dh_shielded] if score @s dh_v matches 1.. run function dungeon_heroes:mech/shielded_on
execute unless entity @s[tag=dh_shielded] run function dungeon_heroes:mech/shielded_off
execute if score @s dh_v matches ..0 run function dungeon_heroes:mech/shielded_off
