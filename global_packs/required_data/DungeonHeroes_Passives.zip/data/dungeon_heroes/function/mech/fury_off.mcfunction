attribute @s minecraft:generic.attack_damage modifier remove dungeon_heroes:fury
attribute @s minecraft:generic.attack_speed modifier remove dungeon_heroes:fury
