attribute @s spell_power:air modifier remove dungeon_heroes:stormborn
attribute @s spell_power:lightning modifier remove dungeon_heroes:stormborn
attribute @s spell_power:water modifier remove dungeon_heroes:stormborn
