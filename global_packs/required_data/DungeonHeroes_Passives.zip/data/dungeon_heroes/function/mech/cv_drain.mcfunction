# conversion step 2 (macro: id, src): src loses its whole bonus (modifier dungeon_heroes:<id> = −dh_v)
execute store result storage dungeon_heroes:cv amt double -0.01 run scoreboard players get @s dh_v
$data modify storage dungeon_heroes:cv id set value "$(id)"
$data modify storage dungeon_heroes:cv attr set value "$(src)"
function dungeon_heroes:mech/cv_add with storage dungeon_heroes:cv
