# conversion step 2 (macro: id, src), every run (cv_read took the drain off): src keeps only its base — final multiplier base/value − 1 (add_multiplied_total, applied after every +% node)
execute if score @s dh_v matches ..0 run return 0
scoreboard players set #k dh_const 10000
scoreboard players operation @s dh_b *= #k dh_const
scoreboard players operation @s dh_b /= @s dh_w
scoreboard players operation @s dh_b -= #k dh_const
execute store result storage dungeon_heroes:cv amt double 0.0001 run scoreboard players get @s dh_b
$data modify storage dungeon_heroes:cv id set value "$(id)"
$data modify storage dungeon_heroes:cv attr set value "$(src)"
function dungeon_heroes:mech/cv_mul with storage dungeon_heroes:cv
