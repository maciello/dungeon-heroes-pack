effect clear @s minecraft:absorption
execute if entity @s[tag=!dh_bastion] run effect give @s minecraft:absorption infinite 0 true
execute if entity @s[tag=dh_bastion] run effect give @s minecraft:absorption infinite 1 true
tag @s remove dh_hit
tag @s add dh_aegis_on
playsound minecraft:item.armor.equip_chain player @s ~ ~ ~ 0.6 1.6
