function dungeon_heroes:mech/oath_off
attribute @s spell_power:water modifier add dungeon_heroes:oath 0.3 add_multiplied_base
attribute @s spell_power:critical_chance modifier add dungeon_heroes:oath 8 add_value
