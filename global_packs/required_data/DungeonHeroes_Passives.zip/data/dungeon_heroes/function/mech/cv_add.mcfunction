# (macro: id, attr, amt) one flat modifier, replaced
$attribute @s $(attr) modifier remove dungeon_heroes:$(id)
$attribute @s $(attr) modifier add dungeon_heroes:$(id) $(amt) add_value
