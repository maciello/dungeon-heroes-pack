# Deep Delver: below y 0 → +8 mining efficiency, +4 armor, night vision (tag dh_delver)
execute if entity @s[tag=dh_delver] if predicate dungeon_heroes:deep run function dungeon_heroes:mech/delver_on
execute unless entity @s[tag=dh_delver] run function dungeon_heroes:mech/delver_off
execute unless predicate dungeon_heroes:deep run function dungeon_heroes:mech/delver_off
