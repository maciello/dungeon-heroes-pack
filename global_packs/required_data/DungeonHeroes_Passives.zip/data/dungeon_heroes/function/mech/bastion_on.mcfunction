attribute @s minecraft:generic.max_absorption modifier add dungeon_heroes:bastion 4 add_value
tag @s add dh_bastion_mod
