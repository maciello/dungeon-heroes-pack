execute store result score @s dh_v run attribute @s spell_power:arcane get
execute store result score @s dh_b run attribute @s spell_power:frost get
scoreboard players operation @s dh_v += @s dh_b
execute store result score @s dh_b run attribute @s spell_power:healing get
scoreboard players operation @s dh_v += @s dh_b
scoreboard players operation @s dh_v /= #10 dh_const
execute if score @s dh_v matches 6.. run scoreboard players set @s dh_v 5
tag @s remove dh_hit
execute if score @s dh_v matches ..0 run return 0
scoreboard players remove @s dh_v 1
execute store result storage dungeon_heroes:cv lvl int 1 run scoreboard players get @s dh_v
effect clear @s minecraft:absorption
function dungeon_heroes:mech/barrier_give with storage dungeon_heroes:cv
tag @s add dh_barrier_on
playsound minecraft:block.amethyst_block.chime player @s ~ ~ ~ 0.6 1.4
