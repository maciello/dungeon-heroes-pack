attribute @s ranged_weapon:damage modifier remove dungeon_heroes:night_hunter
attribute @s critical_strike:chance modifier remove dungeon_heroes:night_hunter
