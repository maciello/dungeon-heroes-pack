attribute @s spell_power:arcane modifier remove dungeon_heroes:shielded
attribute @s spell_power:fire modifier remove dungeon_heroes:shielded
attribute @s spell_power:frost modifier remove dungeon_heroes:shielded
