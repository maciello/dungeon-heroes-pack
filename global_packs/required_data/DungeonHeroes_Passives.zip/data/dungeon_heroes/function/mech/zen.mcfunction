# Zen: at full health → +25 % all spell power (tag dh_zen)
execute if entity @s[tag=dh_zen] if entity @s[scores={dh_pct=100..}] run function dungeon_heroes:mech/zen_on
execute unless entity @s[tag=dh_zen] run function dungeon_heroes:mech/zen_off
execute unless entity @s[scores={dh_pct=100..}] run function dungeon_heroes:mech/zen_off
