# before dh_addon 1.3.0 Aegis and Barrier were an infinite Absorption effect (tags dh_aegis_on, dh_barrier_on): clear it once
effect clear @s minecraft:absorption
tag @s remove dh_aegis_on
tag @s remove dh_barrier_on
