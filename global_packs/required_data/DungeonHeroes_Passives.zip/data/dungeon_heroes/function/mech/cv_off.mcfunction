# (macro: id, src, d1, d2, d3) the node is gone (respec): every modifier of this conversion off
$attribute @s $(src) modifier remove dungeon_heroes:$(id)
$attribute @s $(d1) modifier remove dungeon_heroes:$(id)_1
$attribute @s $(d2) modifier remove dungeon_heroes:$(id)_2
$attribute @s $(d3) modifier remove dungeon_heroes:$(id)_3
$scoreboard players reset @s dh_$(id)
