attribute @s minecraft:generic.attack_damage modifier add dungeon_heroes:fury 0.3 add_multiplied_base
attribute @s minecraft:generic.attack_speed modifier add dungeon_heroes:fury 0.15 add_multiplied_base
