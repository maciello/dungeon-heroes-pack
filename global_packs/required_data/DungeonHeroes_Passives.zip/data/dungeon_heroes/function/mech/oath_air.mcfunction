function dungeon_heroes:mech/oath_off
attribute @s spell_power:air modifier add dungeon_heroes:oath 0.3 add_multiplied_base
attribute @s spell_power:haste modifier add dungeon_heroes:oath 10 add_value
