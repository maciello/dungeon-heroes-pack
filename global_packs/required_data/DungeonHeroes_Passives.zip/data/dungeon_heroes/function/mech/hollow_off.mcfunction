attribute @s minecraft:generic.max_health modifier remove dungeon_heroes:hollow_hp
attribute @s minecraft:generic.max_health modifier remove dungeon_heroes:hollow
attribute @s minecraft:generic.max_absorption modifier remove dungeon_heroes:hollow
attribute @s minecraft:generic.max_absorption modifier remove dungeon_heroes:hollow_more
attribute @s minecraft:generic.max_absorption modifier remove dungeon_heroes:hollow_1
attribute @s minecraft:generic.armor modifier remove dungeon_heroes:hollow_2
scoreboard players reset @s dh_hollow
tag @s remove dh_hollow_mod
tag @s remove dh_hollow_v2
