attribute @s minecraft:generic.max_absorption modifier add dungeon_heroes:aegis 4 add_value
tag @s add dh_aegis_mod
