# Inverted Mercy: your healing spell power bonus is lost; arcane spell power gains 100 % of it (tag dh_cv_heal_arcane)
execute if entity @s[tag=dh_cv_heal_arcane] run function dungeon_heroes:mech/cv_read {id:"cv_heal_arcane", src:"spell_power:healing"}
execute if entity @s[tag=dh_cv_heal_arcane] if score @s dh_chg matches 1 run function dungeon_heroes:mech/cv_drain {id:"cv_heal_arcane", src:"spell_power:healing"}
execute if entity @s[tag=dh_cv_heal_arcane] if score @s dh_chg matches 1 run function dungeon_heroes:mech/cv_to {id:"cv_heal_arcane", n:1, dst:"spell_power:arcane", pct:100}
execute if entity @s[tag=!dh_cv_heal_arcane] if score @s dh_cv_heal_arcane matches 0.. run function dungeon_heroes:mech/cv_off {id:"cv_heal_arcane", src:"spell_power:healing", d1:"spell_power:arcane", d2:"spell_power:arcane", d3:"spell_power:arcane"}
