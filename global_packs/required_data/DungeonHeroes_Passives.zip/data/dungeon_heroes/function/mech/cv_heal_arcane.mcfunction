# Inverted Mercy (tag=dh_cv_heal_arcane): converted by dh_addon Conversions (Java) — healing % → arcane % in full, flat at 0.6, MORE stays.
# Here only: remove the modifiers of the old datapack conversion once (it read the final value, so MORE compounded per hop).
execute if score @s dh_cv_heal_arcane matches 0.. run function dungeon_heroes:mech/cv_off {id:"cv_heal_arcane", src:"spell_power:healing", d1:"spell_power:arcane", d2:"spell_power:arcane", d3:"spell_power:arcane"}
