attribute @s spell_power:arcane modifier add dungeon_heroes:focus 0.2 add_multiplied_base
attribute @s spell_power:fire modifier add dungeon_heroes:focus 0.2 add_multiplied_base
attribute @s spell_power:frost modifier add dungeon_heroes:focus 0.2 add_multiplied_base
attribute @s spell_power:healing modifier add dungeon_heroes:focus 0.2 add_multiplied_base
attribute @s spell_power:air modifier add dungeon_heroes:focus 0.2 add_multiplied_base
attribute @s spell_power:earth modifier add dungeon_heroes:focus 0.2 add_multiplied_base
attribute @s spell_power:water modifier add dungeon_heroes:focus 0.2 add_multiplied_base
