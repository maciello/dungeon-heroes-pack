# Cloistered Mind (tag dh_cloistered): 40% LESS damage (×0.6 multiplied: every damage spell school, attack damage, ranged damage); healing untouched
execute if entity @s[tag=dh_cloistered,tag=!dh_cloistered_mod] run attribute @s spell_power:arcane modifier add dungeon_heroes:cloistered -0.4 add_multiplied_total
execute if entity @s[tag=dh_cloistered,tag=!dh_cloistered_mod] run attribute @s spell_power:fire modifier add dungeon_heroes:cloistered -0.4 add_multiplied_total
execute if entity @s[tag=dh_cloistered,tag=!dh_cloistered_mod] run attribute @s spell_power:frost modifier add dungeon_heroes:cloistered -0.4 add_multiplied_total
execute if entity @s[tag=dh_cloistered,tag=!dh_cloistered_mod] run attribute @s spell_power:air modifier add dungeon_heroes:cloistered -0.4 add_multiplied_total
execute if entity @s[tag=dh_cloistered,tag=!dh_cloistered_mod] run attribute @s spell_power:earth modifier add dungeon_heroes:cloistered -0.4 add_multiplied_total
execute if entity @s[tag=dh_cloistered,tag=!dh_cloistered_mod] run attribute @s spell_power:water modifier add dungeon_heroes:cloistered -0.4 add_multiplied_total
execute if entity @s[tag=dh_cloistered,tag=!dh_cloistered_mod] run attribute @s spell_power:lightning modifier add dungeon_heroes:cloistered -0.4 add_multiplied_total
execute if entity @s[tag=dh_cloistered,tag=!dh_cloistered_mod] run attribute @s spell_power:soul modifier add dungeon_heroes:cloistered -0.4 add_multiplied_total
execute if entity @s[tag=dh_cloistered,tag=!dh_cloistered_mod] run attribute @s minecraft:generic.attack_damage modifier add dungeon_heroes:cloistered -0.4 add_multiplied_total
execute if entity @s[tag=dh_cloistered,tag=!dh_cloistered_mod] run attribute @s ranged_weapon:damage modifier add dungeon_heroes:cloistered -0.4 add_multiplied_total
execute if entity @s[tag=dh_cloistered,tag=!dh_cloistered_mod] run tag @s add dh_cloistered_mod
execute if entity @s[tag=!dh_cloistered,tag=dh_cloistered_mod] run function dungeon_heroes:mech/cloistered_off
