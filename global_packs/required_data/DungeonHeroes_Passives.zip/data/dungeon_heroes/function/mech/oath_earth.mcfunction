function dungeon_heroes:mech/oath_off
attribute @s spell_power:earth modifier add dungeon_heroes:oath 0.3 add_multiplied_base
attribute @s minecraft:generic.armor_toughness modifier add dungeon_heroes:oath 4 add_value
