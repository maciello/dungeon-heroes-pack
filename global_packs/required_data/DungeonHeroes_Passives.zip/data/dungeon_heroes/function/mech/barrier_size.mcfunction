execute store result score @s dh_v run attribute @s spell_power:arcane get
execute store result score @s dh_b run attribute @s spell_power:frost get
scoreboard players operation @s dh_v += @s dh_b
execute store result score @s dh_b run attribute @s spell_power:healing get
scoreboard players operation @s dh_v += @s dh_b
scoreboard players operation @s dh_v /= #10 dh_const
execute if score @s dh_v matches 6.. run scoreboard players set @s dh_v 5
scoreboard players operation @s dh_v *= #4 dh_const
execute if entity @s[tag=dh_barrier_mod] if score @s dh_v = @s dh_barrier_v run return 0
scoreboard players operation @s dh_barrier_v = @s dh_v
tag @s add dh_barrier_mod
attribute @s minecraft:generic.max_absorption modifier remove dungeon_heroes:barrier
execute if score @s dh_v matches ..0 run return 0
execute store result storage dungeon_heroes:cv amt double 1 run scoreboard players get @s dh_v
data modify storage dungeon_heroes:cv id set value "barrier"
data modify storage dungeon_heroes:cv attr set value "minecraft:generic.max_absorption"
function dungeon_heroes:mech/cv_add with storage dungeon_heroes:cv
