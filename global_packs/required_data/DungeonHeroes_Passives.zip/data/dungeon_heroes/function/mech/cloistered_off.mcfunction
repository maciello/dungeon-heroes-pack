attribute @s spell_power:arcane modifier remove dungeon_heroes:cloistered
attribute @s spell_power:fire modifier remove dungeon_heroes:cloistered
attribute @s spell_power:frost modifier remove dungeon_heroes:cloistered
attribute @s spell_power:air modifier remove dungeon_heroes:cloistered
attribute @s spell_power:earth modifier remove dungeon_heroes:cloistered
attribute @s spell_power:water modifier remove dungeon_heroes:cloistered
attribute @s spell_power:lightning modifier remove dungeon_heroes:cloistered
attribute @s spell_power:soul modifier remove dungeon_heroes:cloistered
attribute @s minecraft:generic.attack_damage modifier remove dungeon_heroes:cloistered
attribute @s ranged_weapon:damage modifier remove dungeon_heroes:cloistered
tag @s remove dh_cloistered_mod
