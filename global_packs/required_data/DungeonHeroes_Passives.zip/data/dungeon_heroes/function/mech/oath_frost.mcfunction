function dungeon_heroes:mech/oath_off
attribute @s spell_power:frost modifier add dungeon_heroes:oath 0.3 add_multiplied_base
attribute @s minecraft:generic.armor modifier add dungeon_heroes:oath 4 add_value
