function dungeon_heroes:mech/oath_off
attribute @s spell_power:frost modifier add dungeon_heroes:oath 0.3 add_multiplied_base
attribute @s more_rpg_classes:freeze_chance modifier add dungeon_heroes:oath 15 add_value
