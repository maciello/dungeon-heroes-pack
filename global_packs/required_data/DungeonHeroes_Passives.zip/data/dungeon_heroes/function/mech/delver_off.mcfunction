attribute @s minecraft:player.mining_efficiency modifier remove dungeon_heroes:delver
attribute @s minecraft:generic.armor modifier remove dungeon_heroes:delver
