# conversion step 1 (macro: id, src): own drain off, then dh_v = src's bonus above its base ×100 (read without the drain, so no feedback loop); dh_chg 1 only when dh_v changed (dst modifiers are not re-set every 5 ticks)
$attribute @s $(src) modifier remove dungeon_heroes:$(id)
$execute store result score @s dh_w run attribute @s $(src) get 100
$execute store result score @s dh_b run attribute @s $(src) base get 100
scoreboard players operation @s dh_v = @s dh_w
scoreboard players operation @s dh_v -= @s dh_b
execute if score @s dh_v matches ..-1 run scoreboard players set @s dh_v 0
scoreboard players set @s dh_chg 0
$execute if score @s dh_v = @s dh_$(id) run return 0
scoreboard players set @s dh_chg 1
$scoreboard players operation @s dh_$(id) = @s dh_v
