attribute @s minecraft:generic.attack_damage modifier remove dungeon_heroes:momentum
attribute @s minecraft:generic.movement_speed modifier remove dungeon_heroes:momentum
