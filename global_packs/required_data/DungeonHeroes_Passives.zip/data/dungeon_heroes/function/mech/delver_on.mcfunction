attribute @s minecraft:player.mining_efficiency modifier add dungeon_heroes:delver 8 add_value
attribute @s minecraft:generic.armor modifier add dungeon_heroes:delver 4 add_value
effect give @s minecraft:night_vision 20 0 true
