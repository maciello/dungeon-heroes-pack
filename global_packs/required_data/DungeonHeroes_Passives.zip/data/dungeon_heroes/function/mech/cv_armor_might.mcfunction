# Unarmored: your armor bonus is lost; +1 attack damage per 4 armor of it (tag dh_cv_armor_might)
execute if entity @s[tag=dh_cv_armor_might] run function dungeon_heroes:mech/cv_read {id:"cv_armor_might", src:"minecraft:generic.armor"}
execute if entity @s[tag=dh_cv_armor_might] run function dungeon_heroes:mech/cv_drain {id:"cv_armor_might", src:"minecraft:generic.armor"}
execute if entity @s[tag=dh_cv_armor_might] if score @s dh_chg matches 1 run function dungeon_heroes:mech/cv_to {id:"cv_armor_might", n:1, dst:"minecraft:generic.attack_damage", pct:25}
execute if entity @s[tag=!dh_cv_armor_might] if score @s dh_cv_armor_might matches 0.. run function dungeon_heroes:mech/cv_off {id:"cv_armor_might", src:"minecraft:generic.armor", d1:"minecraft:generic.attack_damage", d2:"minecraft:generic.attack_damage", d3:"minecraft:generic.attack_damage"}
