effect give @s minecraft:regeneration 5 2 true
effect give @s minecraft:resistance 3 1 true
scoreboard players set @s dh_cd 1200
playsound minecraft:item.totem.use player @s ~ ~ ~ 0.4 1.4
