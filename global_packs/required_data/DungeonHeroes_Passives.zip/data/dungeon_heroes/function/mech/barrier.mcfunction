# Barrier (tag dh_barrier): +2 shield hearts (generic.max_absorption) per 10 arcane + frost + healing spell power, max 10 hearts; dh_addon refills it 4 s after the last hit
execute if entity @s[tag=dh_barrier] run function dungeon_heroes:mech/barrier_size
execute if entity @s[tag=!dh_barrier,tag=dh_barrier_mod] run function dungeon_heroes:mech/barrier_off
