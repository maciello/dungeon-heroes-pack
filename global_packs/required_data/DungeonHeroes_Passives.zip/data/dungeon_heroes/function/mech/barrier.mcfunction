# Barrier (tag dh_barrier): absorption shield, 2 hearts per 10 arcane + frost + healing spell power (max 10 hearts); refills 3 s after the last hit
execute if entity @s[tag=dh_barrier] if score @s dh_calm matches 60.. unless predicate dungeon_heroes:has_absorption run function dungeon_heroes:mech/barrier_refill
execute if entity @s[tag=dh_barrier,tag=dh_hit] if score @s dh_calm matches 60.. unless predicate dungeon_heroes:strong_absorption run function dungeon_heroes:mech/barrier_refill
execute if entity @s[tag=!dh_barrier,tag=dh_barrier_on] run function dungeon_heroes:mech/barrier_off
