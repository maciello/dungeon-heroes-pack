attribute @s spell_power:air modifier add dungeon_heroes:stormborn 0.25 add_multiplied_base
attribute @s spell_power:water modifier add dungeon_heroes:stormborn 0.25 add_multiplied_base
