# (macro: lvl) absorption amplifier lvl = 2 × (lvl + 1) hearts
$effect give @s minecraft:absorption infinite $(lvl) true
