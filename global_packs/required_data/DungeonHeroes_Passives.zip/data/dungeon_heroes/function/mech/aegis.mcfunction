# Aegis (tag dh_aegis; does nothing with Hollow Vessel, tag dh_hollow): +4 generic.max_absorption (2 hearts) and 50% MORE max_absorption, +4 more with Bastion (tag dh_bastion); dh_addon recharges an Aegis shield from 2 s after the last hit at 4 hearts/s (others: 5 s, 2 hearts/s); every source stacks
execute if entity @s[tag=dh_aegis_on] run function dungeon_heroes:mech/absorb_legacy
execute if entity @s[tag=dh_barrier_on] run function dungeon_heroes:mech/absorb_legacy
execute if entity @s[tag=dh_aegis,tag=!dh_hollow,tag=!dh_aegis_mod] run function dungeon_heroes:mech/aegis_on
execute if entity @s[tag=dh_aegis_mod] unless entity @s[tag=dh_aegis,tag=!dh_hollow] run function dungeon_heroes:mech/aegis_off
execute if entity @s[tag=dh_aegis,tag=!dh_hollow,tag=dh_bastion,tag=!dh_bastion_mod] run function dungeon_heroes:mech/bastion_on
execute if entity @s[tag=dh_bastion_mod] unless entity @s[tag=dh_aegis,tag=!dh_hollow,tag=dh_bastion] run function dungeon_heroes:mech/bastion_off
execute if entity @s[tag=dh_aegis,tag=!dh_hollow,tag=!dh_aegis_more] run attribute @s minecraft:generic.max_absorption modifier add dungeon_heroes:aegis_more 0.5 add_multiplied_total
execute if entity @s[tag=dh_aegis,tag=!dh_hollow,tag=!dh_aegis_more] run tag @s add dh_aegis_more
execute if entity @s[tag=dh_aegis_more] unless entity @s[tag=dh_aegis,tag=!dh_hollow] run attribute @s minecraft:generic.max_absorption modifier remove dungeon_heroes:aegis_more
execute if entity @s[tag=dh_aegis_more] unless entity @s[tag=dh_aegis,tag=!dh_hollow] run tag @s remove dh_aegis_more
