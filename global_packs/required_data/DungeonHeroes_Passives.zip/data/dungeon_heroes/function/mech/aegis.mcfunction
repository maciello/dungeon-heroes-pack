# Aegis (tag dh_aegis): +4 generic.max_absorption (2 hearts), +4 more with Bastion (tag dh_bastion); dh_addon refills the shield 4 s after the last hit and every source stacks
execute if entity @s[tag=dh_aegis_on] run function dungeon_heroes:mech/absorb_legacy
execute if entity @s[tag=dh_barrier_on] run function dungeon_heroes:mech/absorb_legacy
execute if entity @s[tag=dh_aegis,tag=!dh_aegis_mod] run function dungeon_heroes:mech/aegis_on
execute if entity @s[tag=!dh_aegis,tag=dh_aegis_mod] run function dungeon_heroes:mech/aegis_off
execute if entity @s[tag=dh_aegis,tag=dh_bastion,tag=!dh_bastion_mod] run function dungeon_heroes:mech/bastion_on
execute if entity @s[tag=dh_bastion_mod] unless entity @s[tag=dh_aegis,tag=dh_bastion] run function dungeon_heroes:mech/bastion_off
