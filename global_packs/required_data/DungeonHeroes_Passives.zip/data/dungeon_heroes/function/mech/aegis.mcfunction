# Aegis (tag dh_aegis): absorption shield 4 (8 with Bastion, tag dh_bastion), refills 4 s after the last hit; stronger absorption (e.g. enchanted golden apple) is left alone
execute if entity @s[tag=dh_aegis,tag=dh_hit] if score @s dh_calm matches 80.. unless predicate dungeon_heroes:strong_absorption run function dungeon_heroes:mech/aegis_refill
execute if entity @s[tag=dh_aegis] if score @s dh_calm matches 80.. unless predicate dungeon_heroes:has_absorption run function dungeon_heroes:mech/aegis_refill
execute if entity @s[tag=!dh_aegis,tag=dh_aegis_on] run function dungeon_heroes:mech/aegis_off
