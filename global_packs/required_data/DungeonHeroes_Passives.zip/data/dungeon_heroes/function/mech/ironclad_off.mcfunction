attribute @s minecraft:generic.armor modifier remove dungeon_heroes:ironclad
attribute @s minecraft:generic.knockback_resistance modifier remove dungeon_heroes:ironclad
