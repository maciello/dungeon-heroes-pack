# Drawn Strength: ranged damage gains 50 % of your attack damage bonus (melee keeps it) (tag dh_cv_might_arrow)
execute if entity @s[tag=dh_cv_might_arrow] run function dungeon_heroes:mech/cv_read {id:"cv_might_arrow", src:"minecraft:generic.attack_damage"}
execute if entity @s[tag=dh_cv_might_arrow] if score @s dh_chg matches 1 run function dungeon_heroes:mech/cv_to {id:"cv_might_arrow", n:1, dst:"ranged_weapon:damage", pct:50}
execute if entity @s[tag=!dh_cv_might_arrow] if score @s dh_cv_might_arrow matches 0.. run function dungeon_heroes:mech/cv_off {id:"cv_might_arrow", src:"minecraft:generic.attack_damage", d1:"ranged_weapon:damage", d2:"ranged_weapon:damage", d3:"ranged_weapon:damage"}
