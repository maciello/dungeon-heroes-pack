attribute @s minecraft:generic.armor modifier add dungeon_heroes:ironclad 0.5 add_multiplied_base
attribute @s minecraft:generic.knockback_resistance modifier add dungeon_heroes:ironclad 0.5 add_value
