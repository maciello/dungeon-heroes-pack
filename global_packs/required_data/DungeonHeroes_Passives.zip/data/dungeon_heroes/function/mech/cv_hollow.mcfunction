# Hollow Vessel (tag dh_hollow): every +1 HP of max health above its base becomes +0.2 absorption hearts (+0.4 HP, before the 60% MORE) and +0.2 armor (+5 HP → 1 heart, 1 armor).
# No cv_drain: the ×0 on max health (modifier dungeon_heroes:hollow) is the drain, cv_read takes it off to read the bonus and it goes straight back on.
execute if entity @s[tag=dh_hollow] run function dungeon_heroes:mech/cv_read {id:"hollow", src:"minecraft:generic.max_health"}
execute if entity @s[tag=dh_hollow] run attribute @s minecraft:generic.max_health modifier add dungeon_heroes:hollow -1 add_multiplied_total
execute if entity @s[tag=dh_hollow] if score @s dh_chg matches 1 run function dungeon_heroes:mech/cv_to {id:"hollow", n:1, dst:"minecraft:generic.max_absorption", pct:40}
execute if entity @s[tag=dh_hollow] if score @s dh_chg matches 1 run function dungeon_heroes:mech/cv_to {id:"hollow", n:2, dst:"minecraft:generic.armor", pct:20}
