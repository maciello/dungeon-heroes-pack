# Momentum: while sprinting → +10 % attack damage, +10 % movement speed (tag dh_momentum)
execute if entity @s[tag=dh_momentum] if predicate dungeon_heroes:sprinting run function dungeon_heroes:mech/momentum_on
execute unless entity @s[tag=dh_momentum] run function dungeon_heroes:mech/momentum_off
execute unless predicate dungeon_heroes:sprinting run function dungeon_heroes:mech/momentum_off
