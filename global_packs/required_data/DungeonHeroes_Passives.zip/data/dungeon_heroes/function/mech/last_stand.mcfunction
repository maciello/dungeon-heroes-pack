# Last Stand (tag dh_last_stand): below 30 % health → Regeneration III 5 s + Resistance II 3 s, once per 60 s
execute if entity @s[tag=dh_last_stand,scores={dh_pct=..29}] unless score @s dh_cd matches 1.. run function dungeon_heroes:mech/last_stand_fire
