attribute @s spell_power:arcane modifier remove dungeon_heroes:glass
attribute @s spell_power:fire modifier remove dungeon_heroes:glass
attribute @s spell_power:frost modifier remove dungeon_heroes:glass
attribute @s spell_power:healing modifier remove dungeon_heroes:glass
attribute @s spell_power:air modifier remove dungeon_heroes:glass
attribute @s spell_power:earth modifier remove dungeon_heroes:glass
attribute @s spell_power:water modifier remove dungeon_heroes:glass
attribute @s spell_power:lightning modifier remove dungeon_heroes:glass
attribute @s spell_power:soul modifier remove dungeon_heroes:glass
tag @s remove dh_glass_mod
tag @s remove dh_glass_m50
