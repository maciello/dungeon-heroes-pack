attribute @s minecraft:generic.max_absorption modifier remove dungeon_heroes:bastion
tag @s remove dh_bastion_mod
