# health % (dh_pct), ticks since the last hit (dh_calm), then every passive-tree mechanic (each checks its own skill tag)
execute store result score @s dh_max run attribute @s minecraft:generic.max_health get
scoreboard players operation @s dh_pct = @s dh_hp
scoreboard players operation @s dh_pct *= #100 dh_const
scoreboard players operation @s dh_pct /= @s dh_max
execute if score @s dh_hurt matches 1.. run tag @s add dh_hit
execute if score @s dh_absorbed matches 1.. run tag @s add dh_hit
execute if score @s dh_hurt matches 1.. run scoreboard players set @s dh_calm 0
execute if score @s dh_absorbed matches 1.. run scoreboard players set @s dh_calm 0
scoreboard players set @s dh_hurt 0
scoreboard players set @s dh_absorbed 0
scoreboard players add @s dh_calm 5
execute if score @s dh_calm matches 1000.. run scoreboard players set @s dh_calm 1000
execute if score @s dh_cd matches 1.. run scoreboard players remove @s dh_cd 5
function dungeon_heroes:mech/aegis
function dungeon_heroes:mech/hollow
function dungeon_heroes:mech/cloistered
function dungeon_heroes:mech/fury
function dungeon_heroes:mech/zen
function dungeon_heroes:mech/last_stand
function dungeon_heroes:mech/bloodthirst
function dungeon_heroes:mech/momentum
function dungeon_heroes:mech/night_hunter
function dungeon_heroes:mech/stormborn
function dungeon_heroes:mech/ironclad
function dungeon_heroes:mech/delver
function dungeon_heroes:mech/cv_arcane_elem
function dungeon_heroes:mech/cv_heal_arcane
function dungeon_heroes:mech/cv_crit_life
function dungeon_heroes:mech/cv_armor_might
function dungeon_heroes:mech/cv_might_arrow
function dungeon_heroes:mech/barrier
function dungeon_heroes:mech/shielded
function dungeon_heroes:mech/forbid
function dungeon_heroes:mech/focus
function dungeon_heroes:mech/oath
scoreboard players set @s dh_kills 0
# free respec for every player (no op): /trigger dh_reset → all 3 skill trees give their points back
scoreboard players enable @s dh_reset
execute if score @s dh_reset matches 1.. run function dungeon_heroes:reset_trees
