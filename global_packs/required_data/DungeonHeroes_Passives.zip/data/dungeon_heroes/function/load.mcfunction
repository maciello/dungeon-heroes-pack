scoreboard objectives add dh_hp health
scoreboard objectives add dh_max dummy
scoreboard objectives add dh_pct dummy
scoreboard objectives add dh_hurt minecraft.custom:minecraft.damage_taken
scoreboard objectives add dh_absorbed minecraft.custom:minecraft.damage_absorbed
scoreboard objectives add dh_kills minecraft.custom:minecraft.mob_kills
scoreboard objectives add dh_calm dummy
scoreboard objectives add dh_cd dummy
scoreboard objectives add dh_const dummy
scoreboard objectives add dh_reset trigger
scoreboard players set #100 dh_const 100
scoreboard players set #10 dh_const 10
scoreboard players set #4 dh_const 4
scoreboard objectives add dh_barrier_v dummy
scoreboard objectives add dh_v dummy
scoreboard objectives add dh_b dummy
scoreboard objectives add dh_w dummy
scoreboard objectives add dh_chg dummy
scoreboard objectives add dh_cv_arcane_elem dummy
scoreboard objectives add dh_cv_heal_arcane dummy
scoreboard objectives add dh_cv_crit_life dummy
scoreboard objectives add dh_cv_armor_might dummy
scoreboard objectives add dh_hollow dummy
scoreboard objectives add dh_cv_might_arrow dummy
schedule function dungeon_heroes:tick 5t replace
