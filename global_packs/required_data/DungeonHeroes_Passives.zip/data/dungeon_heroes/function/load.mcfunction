scoreboard objectives add dh_hp health
scoreboard objectives add dh_max dummy
scoreboard objectives add dh_pct dummy
scoreboard objectives add dh_hurt minecraft.custom:minecraft.damage_taken
scoreboard objectives add dh_absorbed minecraft.custom:minecraft.damage_absorbed
scoreboard objectives add dh_kills minecraft.custom:minecraft.mob_kills
scoreboard objectives add dh_calm dummy
scoreboard objectives add dh_cd dummy
scoreboard objectives add dh_const dummy
scoreboard players set #100 dh_const 100
schedule function dungeon_heroes:tick 5t replace
