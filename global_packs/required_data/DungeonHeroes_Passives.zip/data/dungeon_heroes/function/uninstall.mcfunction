# removes every passive-tree modifier/effect/objective from all online players (run before deleting the datapack)
execute as @a run attribute @s minecraft:generic.attack_damage modifier remove dungeon_heroes:fury
execute as @a run attribute @s minecraft:generic.attack_speed modifier remove dungeon_heroes:fury
execute as @a run attribute @s spell_power:arcane modifier remove dungeon_heroes:zen
execute as @a run attribute @s spell_power:fire modifier remove dungeon_heroes:zen
execute as @a run attribute @s spell_power:frost modifier remove dungeon_heroes:zen
execute as @a run attribute @s spell_power:lightning modifier remove dungeon_heroes:zen
execute as @a run attribute @s spell_power:soul modifier remove dungeon_heroes:zen
execute as @a run attribute @s spell_power:healing modifier remove dungeon_heroes:zen
execute as @a run attribute @s spell_power:air modifier remove dungeon_heroes:zen
execute as @a run attribute @s spell_power:earth modifier remove dungeon_heroes:zen
execute as @a run attribute @s spell_power:water modifier remove dungeon_heroes:zen
execute as @a run attribute @s spell_power:nature modifier remove dungeon_heroes:zen
execute as @a run attribute @s minecraft:generic.attack_damage modifier remove dungeon_heroes:momentum
execute as @a run attribute @s minecraft:generic.movement_speed modifier remove dungeon_heroes:momentum
execute as @a run attribute @s ranged_weapon:damage modifier remove dungeon_heroes:night_hunter
execute as @a run attribute @s critical_strike:chance modifier remove dungeon_heroes:night_hunter
execute as @a run attribute @s spell_power:air modifier remove dungeon_heroes:stormborn
execute as @a run attribute @s spell_power:lightning modifier remove dungeon_heroes:stormborn
execute as @a run attribute @s spell_power:water modifier remove dungeon_heroes:stormborn
execute as @a run attribute @s minecraft:generic.armor modifier remove dungeon_heroes:ironclad
execute as @a run attribute @s minecraft:generic.knockback_resistance modifier remove dungeon_heroes:ironclad
execute as @a run attribute @s minecraft:player.mining_efficiency modifier remove dungeon_heroes:delver
execute as @a run attribute @s minecraft:generic.armor modifier remove dungeon_heroes:delver
execute as @a[tag=dh_aegis_mod] run function dungeon_heroes:mech/aegis_off
execute as @a[tag=dh_bastion_mod] run function dungeon_heroes:mech/bastion_off
tag @a remove dh_hit
scoreboard objectives remove dh_hp
scoreboard objectives remove dh_max
scoreboard objectives remove dh_pct
scoreboard objectives remove dh_hurt
scoreboard objectives remove dh_absorbed
scoreboard objectives remove dh_kills
scoreboard objectives remove dh_calm
scoreboard objectives remove dh_cd
scoreboard objectives remove dh_const
schedule clear dungeon_heroes:tick
scoreboard objectives remove dh_reset
execute as @a run function dungeon_heroes:mech/cv_off {id:"cv_arcane_elem", src:"spell_power:arcane", d1:"spell_power:fire", d2:"spell_power:frost", d3:"spell_power:air"}
execute as @a run function dungeon_heroes:mech/cv_off {id:"cv_heal_arcane", src:"spell_power:healing", d1:"spell_power:arcane", d2:"spell_power:arcane", d3:"spell_power:arcane"}
execute as @a run function dungeon_heroes:mech/cv_off {id:"cv_crit_life", src:"critical_strike:chance", d1:"minecraft:generic.max_health", d2:"minecraft:generic.max_health", d3:"minecraft:generic.max_health"}
execute as @a run function dungeon_heroes:mech/cv_off {id:"cv_armor_might", src:"minecraft:generic.armor", d1:"minecraft:generic.attack_damage", d2:"minecraft:generic.attack_damage", d3:"minecraft:generic.attack_damage"}
execute as @a run function dungeon_heroes:mech/cv_off {id:"cv_might_arrow", src:"minecraft:generic.attack_damage", d1:"ranged_weapon:damage", d2:"ranged_weapon:damage", d3:"ranged_weapon:damage"}
execute as @a run function dungeon_heroes:mech/shielded_off
execute as @a[tag=dh_barrier_mod] run function dungeon_heroes:mech/barrier_off
scoreboard objectives remove dh_barrier_v
scoreboard objectives remove dh_v
scoreboard objectives remove dh_b
scoreboard objectives remove dh_chg
scoreboard objectives remove dh_cv_arcane_elem
scoreboard objectives remove dh_cv_heal_arcane
scoreboard objectives remove dh_cv_crit_life
scoreboard objectives remove dh_cv_armor_might
scoreboard objectives remove dh_cv_might_arrow
execute as @a run attribute @s minecraft:generic.max_absorption modifier remove dungeon_heroes:no_absorb
execute as @a run attribute @s critical_strike:chance modifier remove dungeon_heroes:no_crit
execute as @a run attribute @s minecraft:generic.attack_damage modifier remove dungeon_heroes:no_melee
execute as @a run attribute @s ranged_weapon:damage modifier remove dungeon_heroes:no_ranged
execute as @a run attribute @s spell_power:arcane modifier remove dungeon_heroes:no_spell
execute as @a run attribute @s spell_power:fire modifier remove dungeon_heroes:no_spell
execute as @a run attribute @s spell_power:frost modifier remove dungeon_heroes:no_spell
execute as @a run attribute @s spell_power:lightning modifier remove dungeon_heroes:no_spell
execute as @a run attribute @s spell_power:soul modifier remove dungeon_heroes:no_spell
execute as @a run attribute @s spell_power:healing modifier remove dungeon_heroes:no_spell
execute as @a run attribute @s spell_power:air modifier remove dungeon_heroes:no_spell
execute as @a run attribute @s spell_power:earth modifier remove dungeon_heroes:no_spell
execute as @a run attribute @s spell_power:water modifier remove dungeon_heroes:no_spell
execute as @a run attribute @s spell_power:nature modifier remove dungeon_heroes:no_spell
execute as @a run function dungeon_heroes:mech/focus_off
execute as @a run function dungeon_heroes:mech/oath_off
