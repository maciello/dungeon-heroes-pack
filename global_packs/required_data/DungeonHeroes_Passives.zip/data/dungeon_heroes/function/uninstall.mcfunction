# removes every passive-tree modifier/effect/objective from all online players (run before deleting the datapack)
execute as @a run attribute @s minecraft:generic.attack_damage modifier remove dungeon_heroes:fury
execute as @a run attribute @s minecraft:generic.attack_speed modifier remove dungeon_heroes:fury
execute as @a run attribute @s spell_power:arcane modifier remove dungeon_heroes:zen
execute as @a run attribute @s spell_power:fire modifier remove dungeon_heroes:zen
execute as @a run attribute @s spell_power:frost modifier remove dungeon_heroes:zen
execute as @a run attribute @s spell_power:lightning modifier remove dungeon_heroes:zen
execute as @a run attribute @s spell_power:soul modifier remove dungeon_heroes:zen
execute as @a run attribute @s spell_power:healing modifier remove dungeon_heroes:zen
execute as @a run attribute @s spell_power:air modifier remove dungeon_heroes:zen
execute as @a run attribute @s spell_power:earth modifier remove dungeon_heroes:zen
execute as @a run attribute @s spell_power:water modifier remove dungeon_heroes:zen
execute as @a run attribute @s spell_power:nature modifier remove dungeon_heroes:zen
execute as @a run attribute @s minecraft:generic.attack_damage modifier remove dungeon_heroes:momentum
execute as @a run attribute @s minecraft:generic.movement_speed modifier remove dungeon_heroes:momentum
execute as @a run attribute @s ranged_weapon:damage modifier remove dungeon_heroes:night_hunter
execute as @a run attribute @s critical_strike:chance modifier remove dungeon_heroes:night_hunter
execute as @a run attribute @s spell_power:air modifier remove dungeon_heroes:stormborn
execute as @a run attribute @s spell_power:lightning modifier remove dungeon_heroes:stormborn
execute as @a run attribute @s spell_power:water modifier remove dungeon_heroes:stormborn
execute as @a run attribute @s minecraft:generic.armor modifier remove dungeon_heroes:ironclad
execute as @a run attribute @s minecraft:generic.knockback_resistance modifier remove dungeon_heroes:ironclad
execute as @a run attribute @s minecraft:player.mining_efficiency modifier remove dungeon_heroes:delver
execute as @a run attribute @s minecraft:generic.armor modifier remove dungeon_heroes:delver
effect clear @a[tag=dh_aegis_on] minecraft:absorption
tag @a remove dh_aegis_on
tag @a remove dh_hit
scoreboard objectives remove dh_hp
scoreboard objectives remove dh_max
scoreboard objectives remove dh_pct
scoreboard objectives remove dh_hurt
scoreboard objectives remove dh_absorbed
scoreboard objectives remove dh_kills
scoreboard objectives remove dh_calm
scoreboard objectives remove dh_cd
scoreboard objectives remove dh_const
schedule clear dungeon_heroes:tick
